
public abstract class Computador {
	
	protected String ram;
	protected String hd;
	protected String cpu;

}
