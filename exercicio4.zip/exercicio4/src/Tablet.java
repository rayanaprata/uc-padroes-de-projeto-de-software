
public class Tablet {

	public String getInfo7() {
		return "Tablet";
	}

}
