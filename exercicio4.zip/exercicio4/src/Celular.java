
public class Celular {

	public String getInfomacao() {
		return "Celular";
	}	

}
