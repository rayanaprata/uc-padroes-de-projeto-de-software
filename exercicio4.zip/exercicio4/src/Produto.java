
public class Produto {

	public char[] getInfo() {
		
		return null;
	}

}