
public interface ProdutoFactory {

	Produto criar();
	
}
