
public class DispositivosMoveisFactory implements ProdutoFactory {

	public DispositivosMoveisFactory(String string) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Produto criar() {
		// TODO Auto-generated method stub
		return null;
	}

}
