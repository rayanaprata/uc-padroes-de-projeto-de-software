
public class ComputadorFactory implements ProdutoFactory {

	public ComputadorFactory(String string, String string2, String string3, String string4) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Produto criar() {
		// TODO Auto-generated method stub
		return null;
	}

}

