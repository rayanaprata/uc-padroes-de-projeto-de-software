
public class CompressionFactory {

}