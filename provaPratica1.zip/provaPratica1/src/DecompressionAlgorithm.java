
public interface DecompressionAlgorithm {
	
	public String decompress (String string);

}
