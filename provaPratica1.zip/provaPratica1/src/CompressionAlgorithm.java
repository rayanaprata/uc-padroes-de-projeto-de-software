
public interface CompressionAlgorithm {

	public String compress (String string);
	
}
