package facade1;

public class Hotel {

	public boolean isAvailable() {
		return true;
	}

	public void reservarHotel() {
		System.out.println("Hotel Reservado");
	}

}
