package facade2;

public class Quadradro implements Forma {

	   @Override
	   public void desenhar() {
	      System.out.println("Quadrado::desenhar()");
	   }
	}