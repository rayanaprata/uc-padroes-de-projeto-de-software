package facade2;

public class Trapezio implements Forma{

	@Override
	public void desenhar() {
		System.out.println("Trapezio::desenhar()");
	}

}
