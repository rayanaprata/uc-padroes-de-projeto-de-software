package facade2;

public interface Forma {
	void desenhar();
}