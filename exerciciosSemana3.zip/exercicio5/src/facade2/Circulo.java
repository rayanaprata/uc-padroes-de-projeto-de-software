package facade2;

public class Circulo implements Forma {

	@Override
	public void desenhar() {
		System.out.println("Circulo::desenhar()");
	}
}