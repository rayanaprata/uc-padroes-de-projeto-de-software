package facade2;

public class Retangulo implements Forma {

	@Override
	public void desenhar() {
		System.out.println("Retangulo::desenhar()");
	}
}