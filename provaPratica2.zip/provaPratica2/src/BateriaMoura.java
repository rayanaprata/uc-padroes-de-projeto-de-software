
public class BateriaMoura implements Bateria{

	@Override
	public String getDescricao() {
		return "Moura";
	}

}
