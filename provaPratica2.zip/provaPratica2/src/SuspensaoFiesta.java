
public class SuspensaoFiesta implements Suspensao{

	@Override
	public String getDescricao() {
		return "Independente Multilink na dianteira e eixo de tor��o na traseira";
	}

}
