
public class MotorFiesta implements Motor{

	@Override
	public String getDescricao() {
		return "Dianteiro, transversal, 3 cilindros em linha, 1.0, 12V, comando duplo, turbo, inje��o direta de gasolina.\n" +
				" Pot�ncia: 125 cv a 6.000 rpm\n" + 
				" Torque: 17,3 kgfm a 1.400 rpm";
	}

}
