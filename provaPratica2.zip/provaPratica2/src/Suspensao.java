
public interface Suspensao {
	public String getDescricao();
}
