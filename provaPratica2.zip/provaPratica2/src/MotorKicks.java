
public class MotorKicks implements Motor{

	@Override
	public String getDescricao() {
		return "Dianteiro, transversal, 4 cilindros em linha, 16V, comando duplo, flex\n" + 
				" Cilindrada: 1.598 cm�\n" + 
				" Pot�ncia: 114  cv a 5.600 rpm\n" + 
				" Torque: 15,5 kgfm a 4.000 rpm";
	}

}
