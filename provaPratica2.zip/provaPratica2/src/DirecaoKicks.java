
public class DirecaoKicks implements Direcao{

	@Override
	public String getDescricao() {
		return "El�trica";
	}

}
