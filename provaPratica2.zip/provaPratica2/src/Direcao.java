
public interface Direcao {
	public String getDescricao();
}
