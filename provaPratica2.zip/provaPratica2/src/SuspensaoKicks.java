
public class SuspensaoKicks implements Suspensao{

	@Override
	public String getDescricao() {
		return "Independente McPherson na dianteira e eixo de tor��o na traseira";
	}

}
