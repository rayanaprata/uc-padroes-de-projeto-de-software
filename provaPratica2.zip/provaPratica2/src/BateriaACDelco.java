
public class BateriaACDelco implements Bateria{

	@Override
	public String getDescricao() {
		return "ACDelco";
	}

}
