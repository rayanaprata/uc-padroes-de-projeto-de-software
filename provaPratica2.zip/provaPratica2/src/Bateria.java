
public interface Bateria {
	public String getDescricao();
}
