
public interface Motor {
	public String getDescricao();
}
