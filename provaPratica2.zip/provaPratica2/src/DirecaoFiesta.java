
public class DirecaoFiesta implements Direcao{

	@Override
	public String getDescricao() {
		return "Hidr�ulica";
	}

}
