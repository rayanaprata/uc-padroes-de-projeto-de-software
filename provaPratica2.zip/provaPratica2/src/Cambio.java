
public interface Cambio {
	
	public Cambio aumentarMarcha();
	public Cambio diminuirMarcha();
	public Cambio desligar();
	public Cambio ligar();

}
